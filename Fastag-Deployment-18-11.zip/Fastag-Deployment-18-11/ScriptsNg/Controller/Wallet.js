﻿app.controller("WalletController", function ($scope, $http, $filter) {
    $scope.model = {};
    $scope.showDetails = false;
    $scope.detailsFound = false;
    $scope.VehicleRespMsg="";    
    $scope.model.Id = GetParameterValue("Id", 0);
    $scope.model.IsEdit = false;
    $scope.IsApproved = false;


    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }




    $scope.GetDetails = function () {
        debugger;
        var id = parseInt($scope.model.Id);
        if (id > 0) {

            debugger
            $http({
                method: "Get",
                url: baseUrl + 'WalletRecharge/GetDetails?Id=' + $scope.model.Id,
                showloader: true,
            }).success(function (response) {
                debugger
                $scope.model = {};
                if (response) {
                    for (var i = 0; i < response.length; i++) {
                        $scope.model.IsEdit = true;
                        $scope.model.Id = response[i].Id;
                        $scope.model.VehicleRegNo = response[i].VehicleRegNo;
                        $scope.model.Amount = response[i].Amount;                       
                        $scope.model.PaymentType = response[i].PaymentType;
                        $scope.model.FromAccountNumber = response[i].FromAccountNumber;
                        $scope.model.ToAccountNumber = response[i].ToAccountNumber;                                       
                        $scope.model.FinacleReference = response[i].FinacleReference;
                        $scope.model.TransactionId = response[i].TransactionId;
                        $scope.model.WLTransactionId = response[i].WLTransactionId;
                        $scope.model.AmountDeducted = response[i].AmountDeducted;
                        $scope.model.RechargeSuccess = response[i].RechargeSuccess;
                        if (response[i].StatusName == "Approved") {
                            $scope.IsApproved = true;
                        }
                        else {
                            $scope.IsApproved = false;
                        }
                        if ($scope.model.AmountDeducted == true)

                            $scope.model.AmountDeductedString = "Yes";
                        else
                            $scope.model.AmountDeductedString = "No";

                        if ($scope.model.RechargeSuccess == true)

                            $scope.model.RechargeSuccessString = "Yes";
                        else
                            $scope.model.RechargeSuccessString = "No";

                                             
                    }

                }



            });
        }
        else {

            $scope.model.PaymentType = 'Transfer'
            $scope.model.ToAccountNumber = $("#someValues").val();
        }
    }

    $scope.GetDetails();


    $scope.Cancel = function () {

        window.location = "/WalletRecharge/List";
    }

    $scope.CheckCustomer = function () {

        $scope.VehicleRespMsg = "";
        if ($scope.model.VehicleRegNo == "" || $scope.model.VehicleRegNo == null || $scope.model.VehicleRegNo == undefined) {
            WarnMessage("Please enter Vehicle Registration Number");
            return false;

        }
        else {
            $scope.ShowLoaderImg();
            $scope.VehicleParams = {};
            $scope.VehicleParams.vrn = $scope.model.VehicleRegNo;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/CheckFastagBalance',
                data: $scope.VehicleParams,
            }).then(function (response) {
                
                $scope.HideLoaderImg();

                $scope.showDetails = true;
                var result = [];

                $scope.details = [];

                if (response.data.Result.data.length > 0) {
                    for (var i = 0; i < response.data.Result.data.length; i++) {

                        result.push({ CustomerName: response.data.Result.data[i].customerName, MasterBalance: response.data.Result.data[i].masterBalance, MobileNum: response.data.Result.data[i].mobileNum, WalletBalance: response.data.Result.data[i].walletBalance, VRN: response.data.Result.data[i].vrn });
                        $scope.detailsFound = true;
                    }

                }
                else {
                      if(response.data.Result!=null)
                    {
                      $scope.VehicleRespMsg=response.data.Result.respMessage;
                   }
                }
                $scope.details = result;
                
                $scope.HideLoaderImg();





            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });
        }


    }



    $scope.CheckBalance = function (e) {
        if ($scope.model.FromAccountNumber == "" || $scope.model.FromAccountNumber == null || $scope.model.FromAccountNumber == undefined) {
            WarnMessage("Please enter Customer A/C No.");
            return false;

        }
        else {
            $scope.ShowLoaderImg();
            $http({
                method: 'POST',
                url: baseUrl + 'Fastag/CheckAccountBalance?Id=' + $scope.model.FromAccountNumber,

            }).then(function (response) {
                
                $scope.HideLoaderImg();
                alert(response.data);

            }, function errorCallback(response) {
                $scope.HideLoaderImg();


            });
        }
    }


    $scope.Submit = function () {
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();

            $scope.WalletRecharge = {};
            $scope.WalletRecharge.Id = $scope.model.Id;
            $scope.WalletRecharge.VehicleRegNo = $scope.model.VehicleRegNo;
            $scope.WalletRecharge.Amount = $scope.model.Amount;
            $scope.WalletRecharge.FromAccountNumber = $scope.model.FromAccountNumber;
            $scope.WalletRecharge.ToAccountNumber = $scope.model.ToAccountNumber;
            $scope.WalletRecharge.PaymentType = $scope.model.PaymentType;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/SaveRecharge',
                data: $scope.WalletRecharge,
            }).then(function (response) {

                
                $scope.HideLoaderImg();

                if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "exception") {
                        alert(response.data.split('-')[2]);

                    }
                }
                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "insuffiecient") {
                        SetMessage('Insufficient')
                    }
                }

               else (response.data.split('-')[0] == "failure") {
                    alert(response.data.split('-')[2]);
                }

                                           
                 if (response.data.split('-')[0] == "success") {                     
                        
                     window.location = "/WalletRecharge/List";
                     SetMessage("Save");
                }
                 if (response.data.split('-')[0] == "failureRecharge") {
                    alert(response.data.split('-')[1]);
                }
               





            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

        }
        }
    


    $scope.Update = function () {
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();

            $scope.WalletRecharge = {};
            $scope.WalletRecharge.Id = $scope.model.Id;
            $scope.WalletRecharge.VehicleRegNo = $scope.model.VehicleRegNo;
            $scope.WalletRecharge.Amount = $scope.model.Amount;
            $scope.WalletRecharge.FromAccountNumber = $scope.model.FromAccountNumber;
            $scope.WalletRecharge.ToAccountNumber = $scope.model.ToAccountNumber;
            $scope.WalletRecharge.PaymentType = $scope.model.PaymentType;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/UpdateRecharge',
                data: $scope.WalletRecharge,
            }).then(function (response) {


                $scope.HideLoaderImg();


                if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "exception") {
                        alert(response.data.split('-')[2]);

                    }
                }
                else if (response.data.split('-')[0] == "failure") {
                    if (response.data.split('-')[1] == "insuffiecient") {
                        SetMessage('Insufficient')
                    }
                }

                else (response.data.split('-')[0] == "failure") {
                    alert(response.data.split('-')[2]);
                }

                 if (response.data.split('-')[0] == "success") {

                    
                    window.location = "/WalletRecharge/List";
                     SetMessage("Update");

                }
                






            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

        }
    }




   





});