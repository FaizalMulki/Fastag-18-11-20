﻿using iTextSharp.text.pdf;
using MySql.Data.MySqlClient;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using iTextSharp.text;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Drawing2D;
using OrchestratorAsset.Web.CustomModel;
using System.Data;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using System.Net;

using System.Xml.Serialization;
using Vigilance.Web;

namespace OrchestratorAsset.Web.Controllers
{
    [NoDirectAccessAttribute]
    public class FastagController : Controller
    {
        // GET: Fastag
        public ActionResult List()
        {
            return View();
        }

        public ActionResult Registration()
        {
            string actTransNumber =  ConfigurationManager.AppSettings["ActTransNumber"];
            string BranchCode = Session["BranchCode"].ToString();
            ViewBag.ActNumber = BranchCode.ToString() + actTransNumber.ToString();       
            return View();
        }

        public ActionResult Edit(int Id)
        {
            return View();
        }
        public ActionResult GetDetails(int Id)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    MySqlCommand cmd = new MySqlCommand("GetRegisteredItemById", connection);
                    cmd.Parameters.AddWithValue("Id", Id);
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RegisteredList> groups = new List<RegisteredList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RegisteredList>(dt);

                    }

                    return Json(groups, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }

        [HttpPost]
        public JsonResult GetDocuments(int referenceid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    var getDocs = context.Document.Where(p => p.ReferenceId == referenceid && p.IsDeleted==false).ToList();

                    var res = new JsonResult { Data = getDocs, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                    var jsonResult = Json(res, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;


                }
            }



        }


        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }


        public object GetAllItems(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {
                        
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                       
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    DateTime fromDt = DateTime.ParseExact(grid.FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromStr = fromDt.ToString("yyyy-MM-dd");
                    DateTime toDt = DateTime.ParseExact(grid.ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string toStr = toDt.ToString("yyyy-MM-dd");

                    MySqlCommand cmd = new MySqlCommand("GetAllRegisterdItems", connection);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("FromDate", fromStr);
                    cmd.Parameters.AddWithValue("ToDate", toStr);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RegisteredList> groups = new List<RegisteredList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RegisteredList>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        public object GetAllItemsForApproval(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    var branchCode = "";
                    var fullName = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        branchCode = Session["BranchCode"].ToString();
                        fullName = Session["FullName"].ToString();

                    }
                    else
                    {

                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                    }

                    DateTime fromDt = DateTime.ParseExact(grid.FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromStr = fromDt.ToString("yyyy-MM-dd");
                    DateTime toDt = DateTime.ParseExact(grid.ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string toStr = toDt.ToString("yyyy-MM-dd");
                    MySqlCommand cmd = new MySqlCommand("GetAllItemsForApproval", connection);                   
                    cmd.Parameters.AddWithValue("CreatedBy", fullName);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("FromDate", fromStr);
                    cmd.Parameters.AddWithValue("ToDate", toStr);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RegisteredList> groups = new List<RegisteredList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RegisteredList>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }

        [HttpPost]
        public string UpdateRegistration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {

                    var fullName = "";
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        fullName = Session["FullName"].ToString();
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }
                    try
                    {
                        Registration reg = context.Registration
                         .Where(p => p.Id == model.Id).FirstOrDefault();

                        if (reg != null)
                        {
                            reg.FirstName = model.FirstName;

                            reg.LastName = model.LastName;
                            reg.Email = model.Email;
                            reg.Phone = model.Phone;
                            reg.Mobile = model.Mobile;
                            reg.DeliveryAddress = model.DeliveryAddress;
                            reg.VehicleTypeId = model.VehicleTypeId;
                            reg.VehicleRegNo = model.VehicleRegNo;
                            reg.SecurityDeposit = model.SecurityDeposit;
                            reg.FastagFee = model.FastagFee;
                            reg.MinimumBalanceDeposit = model.MinimumBalanceDeposit;
                            reg.Others = model.Others;
                            reg.TotalPayable = model.TotalPayable;
                            reg.IsDeleted = false;
                            reg.ModifiedBy = fullName;
                            reg.ModifiedDate = DateTime.Now;
                            reg.PaymentType = model.PaymentType;
                            reg.FromAccountNumber = model.FromAccountNumber;
                            reg.ToAccountNumber = model.ToAccountNumber;
                            reg.FatherName = model.FatherName;
                            reg.DOB = model.DOB;
                            reg.BranchCode = branchCode;
                            context.SaveChanges();
                            return "success";
                        }
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;
                        return "error";
                    }



                }
            }
            return "error";
        }


        [HttpPost]
        public object Registration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {

                    var fullName = "";
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        fullName = Session["FullName"].ToString();
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    var length = branchCode.Length;
                    var generateNum = "";

                    switch (length)
                    {
                        case 1:
                            generateNum = "000" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        case 2:
                            generateNum = "00" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        case 3:
                            generateNum = "0" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        default:
                            generateNum = branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                    }

                    try
                    {

                        if (model.Id == 0)
                        {
                            var getNumber = context.Registration.Where(x => x.Id > 0).Count() + 1;
                            var refNum = generateNum + getNumber;
                            Registration reg = new Registration();
                            reg.FirstName = model.FirstName;
                            reg.ReferenceNumber = refNum;
                            reg.LastName = model.LastName;
                            reg.Email = model.Email;
                            reg.Phone = model.Phone;
                            reg.Mobile = model.Mobile;
                            reg.DeliveryAddress = model.DeliveryAddress;
                            reg.VehicleTypeId = model.VehicleTypeId;
                            reg.VehicleRegNo = model.VehicleRegNo;
                            reg.SecurityDeposit = model.SecurityDeposit;
                            reg.FastagFee = model.FastagFee;
                            reg.MinimumBalanceDeposit = model.MinimumBalanceDeposit;
                            reg.Others = model.Others;
                            reg.TotalPayable = model.TotalPayable;
                            reg.IsDeleted = false;
                            reg.PaymentType = model.PaymentType;
                            reg.FromAccountNumber = model.FromAccountNumber;
                            reg.ToAccountNumber = model.ToAccountNumber;
                            reg.CreatedBy = fullName;
                            reg.FatherName = model.FatherName;
                            reg.DOB = model.DOB;
                            reg.CreatedDate = DateTime.Now;
                            reg.ModifiedBy = null;
                            reg.ModifiedDate = null;
                            //reg.FinacleTransNumber = result.Split('-')[1];
                            reg.FinacleTransNumber = "123";
                            reg.BranchCode = branchCode;
                            reg.StatusId = (int)Status.Pending;
                            context.Registration.Add(reg);
                            context.SaveChanges();
                            var Id = reg.Id;
                            return Id;

                        }



                    }



                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }



            return null;
        }

        [HttpPost]
        public object OrigRegistration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {

                    var fullName = "";
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        fullName = Session["FullName"].ToString();
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    var length = branchCode.Length;
                    var generateNum = "";

                    switch (length)
                    {
                        case 1:
                            generateNum = "000" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        case 2:
                            generateNum = "00" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        case 3:
                            generateNum = "0" + branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                        default:
                            generateNum = branchCode + DateTime.Now.Day.ToString("00") + DateTime.Now.Month.ToString("00") + DateTime.Now.Year;
                            break;
                    }

                    try
                    {

                        if (model.Id == 0)
                        {
                            var getNumber = context.Registration.Where(x => x.Id > 0).Count() + 1;
                            var refNum = generateNum + getNumber;
                            var checkBal = CheckBalance(model.FromAccountNumber, refNum);
                            if (checkBal.Split('-')[0].ToLower() == "true")
                            {
                                decimal balAmt = Convert.ToDecimal(checkBal.Split('-')[1]);

                                if (balAmt >= model.TotalPayable)
                                {
                                    Registration reg = new Registration();
                                    reg.FirstName = model.FirstName;
                                    reg.ReferenceNumber = refNum;
                                    reg.LastName = model.LastName;
                                    reg.Email = model.Email;
                                    reg.Phone = model.Phone;
                                    reg.Mobile = model.Mobile;
                                    reg.DeliveryAddress = model.DeliveryAddress;
                                    reg.VehicleTypeId = model.VehicleTypeId;
                                    reg.VehicleRegNo = model.VehicleRegNo;
                                    reg.SecurityDeposit = model.SecurityDeposit;
                                    reg.FastagFee = model.FastagFee;
                                    reg.MinimumBalanceDeposit = model.MinimumBalanceDeposit;
                                    reg.Others = model.Others;
                                    reg.TotalPayable = model.TotalPayable;
                                    reg.IsDeleted = false;
                                    reg.PaymentType = model.PaymentType;
                                    reg.FromAccountNumber = model.FromAccountNumber;
                                    reg.ToAccountNumber = model.ToAccountNumber;
                                    reg.CreatedBy = fullName;
                                    reg.CreatedDate = DateTime.Now;
                                    reg.ModifiedBy = null;
                                    reg.ModifiedDate = null;
                                    reg.FatherName = model.FatherName;
                                    reg.DOB = model.DOB;
                                    reg.BranchCode = branchCode;
                                    reg.StatusId = (int)Status.Pending;
                                   // reg.FinacleTransNumber = result.Split('-')[1];
                                    // reg.FinacleTransNumber = "123";
                                    context.Registration.Add(reg);
                                    context.SaveChanges();
                                    var Id = reg.Id;
                                    return Id;


                                }
                                else
                                {
                                    return "insuffiecient";
                                }
                            }
                            else if (checkBal.Split('-')[0].ToLower() == "false" && checkBal.Split('-')[1] == "InvalidAccountNumber")
                            {
                                return "invalidaccount";
                            }
                            else
                            {
                                return "exceptionBal";
                            }


                        }
                        else
                        {
                            return "error";

                        }

                    }
                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }
        }


        [HttpPost]
        public object OrigApproveRegistration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {

                    var fullName = "";
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {
                        fullName = Session["FullName"].ToString();
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    try
                    {
                        var registration = context.Registration.Where(x => x.Id == model.Id).FirstOrDefault();
                        var checkBal = CheckBalance(model.FromAccountNumber.Trim(), registration.ReferenceNumber);
                        if (checkBal.Split('-')[0].ToLower() == "true")
                        {
                            decimal balAmt = Convert.ToDecimal(checkBal.Split('-')[1]);

                            if (balAmt >= model.TotalPayable)
                            {

                                var result = DoTransaction(model);
                                if (result.Split('-')[0].ToLower() == "true")
                                {
                                   // registration.ModifiedBy = fullName;
                                    registration.StatusId = (int)Status.Approved;
                                   // registration.ModifiedDate = DateTime.Now;
                                    registration.FinacleTransNumber = result.Split('-')[1];
                                    registration.ApprovedBy = fullName;
                                    registration.ApproverBranchCode = branchCode;
                                    registration.ApprovedDate = DateTime.Now;
                                    context.SaveChanges();

                                    return "success";
                                }
                                else if (result.Split('-')[0].ToLower() == "false" && result.Split('-')[1] == "ExceptionOccured")
                                {
                                    return "exceptionTrans";

                                }
                                else
                                {
                                    return result.Split('-')[1];

                                }
                            }
                            else
                            {
                                return "insuffiecient";
                            }
                        }
                        else if (checkBal.Split('-')[0].ToLower() == "false" && checkBal.Split('-')[1] == "InvalidAccountNumber")
                        {
                            return "invalidaccount";
                        }
                        else
                        {
                            return "exceptionBal";
                        }

                    }
                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }


        }



        [HttpPost]
        public object ApproveRegistration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {

                    var fullName = "";
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {
                        fullName = Session["FullName"].ToString();
                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];
                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    try
                    {
                        var registration = context.Registration.Where(x => x.Id == model.Id).FirstOrDefault();
                        registration.ModifiedBy = fullName;
                        registration.StatusId = (int)Status.Approved;
                        registration.ModifiedDate = DateTime.Now;
                        registration.ApprovedBy = fullName;
                        registration.ApproverBranchCode = branchCode;
                        registration.ApprovedDate = DateTime.Now;
                        registration.FinacleTransNumber = "123";
                        context.SaveChanges();
                        return "success";

                    }
                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }


        }


        [HttpPost]
        public string DeleteAttachment(int Id)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {

                        var fullName = "";
                       
                        var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                        if (loginFromAD.ToLower().Trim() == "yes")
                        {
                            fullName = Session["FullName"].ToString();
                           

                        }
                        else
                        {
                            fullName = ConfigurationManager.AppSettings["DummyUserName"];
                            
                        }

                        var getDocx = context.Document.Where(x => x.Id == Id).FirstOrDefault();
                        getDocx.IsDeleted = true;
                        getDocx.DeletedBy = fullName;
                        getDocx.DeletedDate = DateTime.Now;
                        context.SaveChanges();
                        return "success";
                    
                           
                       
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;
                        return "error";
                    }
                }
            }
        }

        [HttpPost]
        public virtual string UploadFiles()
        {
            var fullName = "";          
            var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
            if (loginFromAD.ToLower().Trim() == "yes")
            {

                fullName = Session["FullName"].ToString();
                

            }
            else
            {
                fullName = ConfigurationManager.AppSettings["DummyUserName"];
               
            }

            var DeletedDocIds = Request.Headers["X-Deleted-DocId"];
            
            var IsAnyUploads = Request.Headers["X-IsContain-Upload"];
            if (IsAnyUploads == "true")
            {
                var documentname = Request.Headers["X-File-Name"];
                documentname = Server.UrlDecode(documentname);

                var givenName = Request.Headers["X-File-GivenName"];
                givenName = Server.UrlDecode(givenName);
                var IdType= Request.Headers["X-File-IdType"]; 
                var filepath = Request.Headers["X-File-Path"];
                var IsVehicle=  Convert.ToBoolean(Request.Headers["X-File-IsVehicle"]);
                var IsPAN = Convert.ToBoolean(Request.Headers["X-File-IsPAN"]);
                var extension = Path.GetExtension(documentname);
                var fname = Path.GetFileNameWithoutExtension(documentname);
                // var filefullname = Path.GetFileName(fname + "_" + DateTime.Now.ToString("yyyyMMdd_hhmmss")) + extension;

                var filefullname = givenName + "-" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + "-" + extension;
                var length = Request.ContentLength;
                var fullPath = filepath;
                var bytes = new byte[length];
                Request.InputStream.Read(bytes, 0, length);
                int Id = Convert.ToInt32(Request.Headers["X-Reference-Id"]);
                // var fileSize = Request.Headers["X-File-Size"];
                //   var Id = Request.Headers["X-File-Id"];
                using (MySqlConnection connection = new MySqlConnection(Connection()))
                {
                    using (MyDBContext context = new MyDBContext(connection, false))
                    {
                        try
                        {

                            var getReferenceNum = context.Registration.Where(x => x.Id == Id).FirstOrDefault();
                            fullPath = filepath + getReferenceNum.ReferenceNumber + "/";
                            filefullname = givenName + "-" + getReferenceNum.ReferenceNumber + "-" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + "-" + extension; ;
                            DAL.Document d = new DAL.Document();
                            d.Documents = bytes;
                            d.DocumentName = documentname;
                            d.DocumentType = givenName;
                            d.ReferenceId = Id;
                            d.IdType = IdType;
                            d.Extension = Request.Headers["X-File-Type"];
                            d.IsVehicle = IsVehicle;
                            d.IsPAN = IsPAN;
                            d.CreatedBy = fullName;
                            d.IsDeleted = false;
                            d.CreatedDate = DateTime.Now;
                            d.DeletedDate = null;
                            d.DocumentPath = fullPath + filefullname;
                            context.Document.Add(d);
                            context.SaveChanges();
                        }
                        catch (Exception e)
                        {
                            var k = e.Message;
                        }

                    }
                }

                try

                {
                    string folderPath = Server.MapPath(fullPath);
                    //Check whether Directory (Folder) exists.
                    if (!Directory.Exists(folderPath))
                    {
                        //If Directory (Folder) does not exists. Create it.
                        Directory.CreateDirectory(folderPath);
                    }
                    //Save the File to the Directory (Folder).

                    Request.SaveAs(folderPath + filefullname, false);
                }
                catch (Exception ex)
                {
                    var k = ex.Message;
                }

                return string.Format("{0} bytes uploaded", bytes.Length);
            }

            return string.Format("{0} bytes uploaded", 0);
        }





        public Bitmap downloadFromDB()
        {
            MemoryStream mStream = new MemoryStream();
            using (MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings[2].ConnectionString))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        var getDocs = context.Document.Where(p => p.ReferenceId == 1).FirstOrDefault();
                        byte[] pData = getDocs.Documents;
                        FileStream fs;
                        fs = new FileStream(@"D:\newfile.jpeg", FileMode.OpenOrCreate, FileAccess.Write);
                        fs.Write(pData, 0, pData.Length);
                        fs.Close();
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;
                    }
                }
            }
            return null;

        }


        public void Merge()
        {

            string ImagePath = HttpContext.Server.MapPath("~/Content/Fastag");
            string[] filenames = System.IO.Directory.GetFiles(ImagePath);
            string outputFileName = "Merge.pdf";
            string outFilePath = System.Web.Hosting.HostingEnvironment.MapPath("~/Content/Fastag/" + outputFileName);
            iTextSharp.text.Document doc = new iTextSharp.text.Document(PageSize.A4, 0, 0, 0, 0);
            System.IO.Stream st = new FileStream(outFilePath, FileMode.Create, FileAccess.Write);
            PdfWriter writer = PdfWriter.GetInstance(doc, st);
            doc.Open();
            writer.Open();
            for (int i = 0; i < filenames.Length; i++)
            {
                string fname = filenames[i];
                if (System.IO.File.Exists(fname))
                {
                    iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(fname);
                    if (img.Height > img.Width)
                    {
                        float percentage = 0.0f;
                        percentage = 700 / img.Height;
                        img.ScalePercent(percentage * 100);
                    }
                    else
                    {
                        float percentage = 0.0f;
                        percentage = 540 / img.Width;
                        img.ScalePercent(percentage * 100);
                    }
                    img.Border = iTextSharp.text.Rectangle.BOX;
                    img.BorderColor = iTextSharp.text.BaseColor.BLACK;
                    doc.Add(img);
                }
            }
            doc.Close();
            writer.Close();
        }



        public ActionResult Download(int id)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        var details = context.Document.Where(p => p.Id == id).FirstOrDefault();
                        string path = details.DocumentPath;
                        string filenames = "";
                        // Uri uri = new Uri(path);

                        filenames = details.DocumentName;

                        //byte[] fileBytes = System.IO.File.ReadAllBytes(path);
                        //return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, filenames);

                        var fileListing = details;
                        try
                        {
                            if (fileListing.Id == 0)
                                return Content("Failed");
                        }
                        catch (Exception ex)
                        {
                            return Content("Failed");
                        }


                        if (fileListing.Extension == "image/jpg" || fileListing.Extension == "image/jpeg")
                        {
                            byte[] byteArray = fileListing.Documents;
                            return File(byteArray, System.Net.Mime.MediaTypeNames.Application.Octet, filenames);
                           // return File(byteArray, "image/jpeg");
                        }
                        else if (fileListing.Extension == "image/png")
                        {
                            byte[] byteArray = fileListing.Documents;
                            return File(byteArray, System.Net.Mime.MediaTypeNames.Application.Octet, filenames);
                            //  return File(byteArray, "image/png");
                        }
                        else if (fileListing.Extension == "image/tiff")
                        {
                            byte[] byteArray = fileListing.Documents;
                            return File(byteArray, System.Net.Mime.MediaTypeNames.Application.Octet, filenames);
                            //  return File(byteArray, "image/tiff");
                        }




                    }
                    catch (Exception ex)
                    {
                        var k = ex.Message;
                    }




                }
            }
            return null;
        }

        [HttpPost]
        public string CheckAccountBalance(string Id)
        {
            HTTPRequest req = new HTTPRequest();
            string amount = "";
           // string Url = "https://F10DEV.ktkbank.com:20000/FISERVLET/fihttp";
            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();
            // var accountnumber = "0022500100003001";         
            var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
            string requestXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml BalInq.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>" + "Req_" + "123" + " </RequestUUID>\r\n<ServiceRequestId>BalInq</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<BalInqRq>\r\n<AcctId>\r\n<AcctId>" + Id + "</AcctId>\r\n</AcctId>\r\n</BalInqRq>\r\n</Body>\r\n</FIXML>\r\n";

            var response = req.postXMLData(Url, requestXml);
            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(BalanceCheck.FIXML));
                    var result = (BalanceCheck.FIXML)serializer.Deserialize(reader);

                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        amount = result.Body.BalInqResponse.BalInqRs.AcctBalItems.First().BalAmt.amountValue.ToString();
                    }
                    else
                    {
                        amount = result.Body.Error.FIBusinessException.ErrorDetail.ErrorDesc;
                    }
                    return amount;

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }



            }
            return amount;
        }

        public string CheckBalance(string AccountNumber, string ReferenceNumber)
        {
            HTTPRequest req = new HTTPRequest();
            bool success = false;
            var res = "";
            decimal amount = 0;
           // string Url = "https://F10DEV.ktkbank.com:20000/FISERVLET/fihttp";
            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();
            // var accountnumber = "0022500100003001";         
            var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
            string requestXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml BalInq.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>" + "Req_" + ReferenceNumber + " </RequestUUID>\r\n<ServiceRequestId>BalInq</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<BalInqRq>\r\n<AcctId>\r\n<AcctId>" + AccountNumber + "</AcctId>\r\n</AcctId>\r\n</BalInqRq>\r\n</Body>\r\n</FIXML>\r\n";

            var response = req.postXMLData(Url, requestXml);
            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(BalanceCheck.FIXML));
                    var result = (BalanceCheck.FIXML)serializer.Deserialize(reader);

                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        amount = result.Body.BalInqResponse.BalInqRs.AcctBalItems.First().BalAmt.amountValue;
                        success = true;
                        res = success + "-" + amount;
                    }
                    else
                    {
                        success = false;
                        res = success + "-" + result.Body.Error.FIBusinessException.ErrorDetail.ErrorDesc;
                    }
                    return res;

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }



            }
            success = false;
            res = success + "-" + "ExceptionOccured";
            return res;
        }

        public string DoTransaction(Registration model)
        {
            HTTPRequest req = new HTTPRequest();
            bool success = false;
            var res = "";
           // string Url = "https://F10DEV.ktkbank.com:20000/FISERVLET/fihttp";
            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();
            // var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
            var tod = "2020-06-11T13:16:45.302 + 05:30";
            // string requestData = "<?xml version=1.0 encoding=UTF-8?><FIXML xsi:schemaLocation=http://www.finacle.com/fixml BalInq.xsd xmlns= http://www.finacle.com/fixml xmlns:xsi=w3.org/2001/XMLSchema-instance><Header><RequestHeader><MessageKey><RequestUUID>Req_1560515797477</RequestUUID><ServiceRequestId>BalInq</ServiceRequestId><ServiceRequestVersion>10.2</ServiceRequestVersion><ChannelId>COR</ChannelId><LanguageId></LanguageId></MessageKey><RequestMessageInfo><BankId>01</BankId><TimeZone></TimeZone><EntityId></EntityId><EntityType></EntityType><ArmCorrelationId></ArmCorrelationId><MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime></RequestMessageInfo><Security><Token><PasswordToken><UserId></UserId><Password></Password></PasswordToken></Token><FICertToken></FICertToken><RealUserLoginSessionId></RealUserLoginSessionId><RealUser></RealUser><RealUserPwd></RealUserPwd><SSOTransferToken></SSOTransferToken></Security></RequestHeader></Header><Body><BalInqRq><AcctId><AcctId>0022500100003001</AcctId></AcctId></BalInqRq></Body> </ FIXML >";
            //string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_1560515797477</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4732500101964301</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>To Raju</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4362500100484501</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>By Ganesh</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";
            string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_1560515797477</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.FromAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.TotalPayable + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag-Reference Number-" + model.ReferenceNumber + "</TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.ToAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.TotalPayable + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag - Reference Number - " + model.ReferenceNumber + " </TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";

            var response = req.postXMLData(Url, newRequest);

            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(CreditDebitTransaction.FIXML));
                    var result = (CreditDebitTransaction.FIXML)serializer.Deserialize(reader);
                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        var transId = result.Body.XferTrnAddResponse.XferTrnAddRs.TrnIdentifier.TrnId;
                        success = true;
                        res = success + "-" + transId;
                        return res;
                    }
                    else
                    {



                        var error = result.Body.Error.FIBusinessException.ErrorDetail.First().ErrorDesc;

                        success = false;
                        res = success + "-" + error;
                        return res;
                    }



                }
                catch (Exception e)
                {
                    var k = e.Message;
                }

                res = success + "-" + "ExceptionOccured";
                return res;

            }
        }

        class HTTPRequest
        {
            public string postXMLData(string destinationUrl, string requestXml)
            {
                //Bypass SSL Verification
                ServicePointManager.ServerCertificateValidationCallback +=
                    delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
                byte[] bytes;
                bytes = System.Text.Encoding.ASCII.GetBytes(requestXml);


                request.ContentType = "application/xml";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();
                    return responseStr;

                }
                return null;
            }

        }



        [HttpPost]
        public string DeleteRegistration(Registration model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        var checkStatus = context.Registration.Where(x => x.Id == model.Id && x.StatusId == 2).Count();
                        if (checkStatus > 0)
                        {
                            return "dependency";
                        }
                        else
                        {
                            var record = context.Registration.Where(x => x.Id == model.Id).FirstOrDefault().IsDeleted = true;
                            context.SaveChanges();
                            return "success";
                        }
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;

                    }
                }
            }
            return "error";
        }


    }

    enum Status
    {
        Pending = 1,
        Approved = 2


    }

}
