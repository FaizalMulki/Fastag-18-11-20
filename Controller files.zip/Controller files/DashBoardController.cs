﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OrchestratorAsset.Web.CustomModel;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vigilance.Web;

namespace OrchestratorAsset.Web.Controllers
{
    [NoDirectAccessAttribute]
    public class DashBoardController : Controller
    {
        // GET: DashBoard
        public ActionResult Index()
        {
            return View();
        }

        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }

        public object GetStatus()
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                try
                {

                    MySqlCommand cmd = new MySqlCommand("Select Id, Name from status order by Name asc", connection);
                    cmd.CommandType = CommandType.Text;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        List<StatusModel> branch = new List<StatusModel>();
                        branch = CommonMethod.ConvertToList<StatusModel>(dt);
                        return Json(branch, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception e)
                {


                }
            }

            return null;
        }

        public object GetDashBoardHeader()
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                try
                {
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {
                        branchCode = Session["BranchCode"].ToString();
                    }
                    else
                    {

                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    MySqlCommand cmd = new MySqlCommand("GetDashBoardCount", connection);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    //cmd.Parameters.AddWithValue("IsSuperAdmin", Session["IsSuperAdmin"].ToString());
                    //cmd.Parameters.AddWithValue("CreatedBy", Session["FullName"].ToString());
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        List<DashBoardHeader> header = new List<DashBoardHeader>();
                        header = CommonMethod.ConvertToList<DashBoardHeader>(dt);
                        return Json(header, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception e)
                {

                    var k = e.Message;
                }
            }

            return null;
        }




        public object GetAllItemsForDashBoard(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {
                        branchCode = Session["BranchCode"].ToString();
                    }
                    else
                    {

                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }
                    DateTime fromDt = DateTime.ParseExact(grid.FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromStr = fromDt.ToString("yyyy-MM-dd");
                    DateTime toDt = DateTime.ParseExact(grid.ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string toStr = toDt.ToString("yyyy-MM-dd");
                    MySqlCommand cmd = new MySqlCommand("GetAllItemsForDashBoard", connection);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("FromDate", fromStr);
                    cmd.Parameters.AddWithValue("ToDate", toStr);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RegisteredList> groups = new List<RegisteredList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RegisteredList>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }



    }

    public class DashBoardHeader
    {
        public long TotalReg { get; set; }
        public decimal TotalAmount { get; set; }

        public long TotalRech { get; set; }
        public decimal TotalRechAmount { get; set; }
    }
}