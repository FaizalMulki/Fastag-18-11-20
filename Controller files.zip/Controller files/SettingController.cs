﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OrchestratorAsset.Web.CustomModel;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vigilance.Web;

namespace OrchestratorAsset.Web.Controllers
{
    [NoDirectAccessAttribute]
    public class SettingController : Controller
    {
        // GET: Setting
        public ActionResult Index()
        {
            return View();
        }
        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }



        public object GetAllItems(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    MySqlCommand cmd = new MySqlCommand("GetAllSettings", connection);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<SettingList> groups = new List<SettingList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<SettingList>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        public string SubmitInfo(SettingModel model)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    var fullName = "";

                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        fullName = Session["FullName"].ToString();


                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];

                    }



                    try
                    {

                        if (model.Id == 0)
                        {
                            //DateTime fromDt = DateTime.ParseExact(model.EffectiveFrom.ToString(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

                            //string fromStr = fromDt.ToString("yyyy-MM-dd");

                            //DateTime toDt = DateTime.ParseExact(model.EffectiveTo.ToString(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

                            //string toStr = toDt.ToString("yyyy-MM-dd");

                            var checkNameExists = context.Setting.Where(p => p.VehicleTypeId == model.VehicleTypeId && p.IsDeleted == false && p.EffectiveFrom<=model.EffectiveTo && p.EffectiveTo>=model.EffectiveFrom).FirstOrDefault();

                            if (checkNameExists != null)
                            {
                                return "exists";
                            }
                            else
                            {
                                Setting s = new Setting();
                            s.VehicleTypeId = model.VehicleTypeId;
                            s.EffectiveFrom = model.EffectiveFrom;
                            s.EffectiveTo = model.EffectiveTo;
                            s.RefundableSecurityDeposit = model.RefundableSecurityDeposit;
                            s.MinimumBalanceWalletDeposit = model.MinimumBalanceWalletDeposit;
                            s.FastagFee = model.FastagFee;
                            s.Others = model.Others;
                            s.IsDeleted = false;
                            s.CreatedBy = fullName;
                            s.CreatedDate = DateTime.Now;                          
                            context.Setting.Add(s);
                            context.SaveChanges();
                            return "success";
                          }

                        }
                        else
                        {

                            //var checkNameExists = context.Group.Where(p => p.Name.ToLower().Trim() == model.Name.ToLower().Trim() && p.isdeleted == false && p.Id != model.Id).FirstOrDefault();
                            var checkNameExists = context.Setting.Where(p => p.VehicleTypeId == model.VehicleTypeId && p.IsDeleted == false && p.EffectiveFrom <= model.EffectiveTo && p.EffectiveTo >= model.EffectiveFrom && p.Id != model.Id).FirstOrDefault();
                            if (checkNameExists != null)
                            {
                                return "exists";
                            }
                            else
                            {

                                Setting prodToUpdate = context.Setting
                                  .Where(p => p.Id == model.Id).FirstOrDefault();

                                if (prodToUpdate != null)
                                {
                                    prodToUpdate.EffectiveFrom = model.EffectiveFrom;
                                    prodToUpdate.EffectiveTo = model.EffectiveTo;
                                    prodToUpdate.FastagFee = model.FastagFee;
                                    prodToUpdate.MinimumBalanceWalletDeposit = model.MinimumBalanceWalletDeposit;
                                    prodToUpdate.RefundableSecurityDeposit = model.RefundableSecurityDeposit;
                                    prodToUpdate.Others = model.Others;
                                    prodToUpdate.ModifiedBy = fullName;
                                    prodToUpdate.ModifiedDate = DateTime.Now;                               
                                    context.SaveChanges();
                                    return "success";
                                }
                            }

                        }

                    }
                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }

            return "error";
        }


        public object GetVehicleType()
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                try
                {

                    MySqlCommand cmd = new MySqlCommand("Select Id, Type as Name from vehicletype where IsDeleted=0 order by type asc", connection);
                    cmd.CommandType = CommandType.Text;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        List<VehicleTypeDropDown> branch = new List<VehicleTypeDropDown>();
                        branch = CommonMethod.ConvertToList<VehicleTypeDropDown>(dt);
                        return Json(branch, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception e)
                {


                }
            }

            return null;
        }


        public object GetConfiguration(int Id)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                try
                {


                   // DateTime fromDt = DateTime.ParseExact(DateTime.Now.ToShortDateString(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromDate = DateTime.Now.ToShortDateString();
                    //DateTime fromDt = DateTime.ParseExact(fromDate, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    // DateTime fromDt = DateTime.ParseExact(fromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromDatee = DateTime.Now.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture);
                    DateTime fromDt = DateTime.ParseExact(fromDatee, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

                    string fromStr = fromDt.ToString("yyyy-MM-dd");

                    MySqlCommand cmd = new MySqlCommand("CheckDataWithinDateRange", connection);
                    cmd.Parameters.AddWithValue("VehicleTypeId", Id);
                    cmd.Parameters.AddWithValue("EffectiveFrom", fromStr);
                    cmd.Parameters.AddWithValue("EffectiveTo", fromStr);

                    cmd.CommandType = CommandType.StoredProcedure;

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        List<SettingList> branch = new List<SettingList>();
                        branch = CommonMethod.ConvertToList<SettingList>(dt);
                        return Json(branch, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception e)
                {

                    var k = e.Message;
                }
            }

            return null;
        }



        [HttpPost]
        public string Delete(Setting model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        

                        //var checkRegStatus = context.Registration.Where(x => x.VehicleTypeId == model.VehicleTypeId && x.IsDeleted == false).Count();
                        //if (checkRegStatus > 0)
                        //{
                        //    return "dependency";
                        //}

                        var record = context.Setting.Where(x => x.VehicleTypeId == model.VehicleTypeId).FirstOrDefault().IsDeleted = true;
                        context.SaveChanges();
                        return "success";
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;

                    }
                }
            }
            return "error";
        }


    }
}